# OH3C
用于中山大学东校区的 OpenWrt H3C 802.1x 认证客户端 - H3C 802.1x Client for OpenWrt in SYSU East Campus

## Introduction
Includes build settings for OH3C and Python-mini-oh3c-md5. You can compile the packages on the OpenWrt. 

## HOW TO
* Unpack `/python` into the `feeds/pakages/lang`.
* `make menuconfig` into the config menu, select `lang->python`. Choose `oh3c`, `python-mini` or `python-mini-oh3c-m5d` package according to what you need.
* `make V=99`, it would takes a while.

## Thanks

* [nanpuyue/OH3C](https://github.com/nanpuyue/OH3C): We base on the implementation.